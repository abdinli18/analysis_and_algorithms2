/* @Author
Student Name: Elvin Abdinli
Student ID: 150180904*/
/* I took files and scores as main parameters */

#include <iostream>
#include <algorithm>
#include <string>
#include <cstdlib>
#include <vector>
#include <fstream>
#include <set>

using namespace std;

int MATCH;
int MISMATCH;           //global variables used
int GAP;
//#define GAP -4
//#define MISMATCH -2
//#define MATCH 1

int max_score;          //storing maximum score

void my_func(string A, string B, ofstream& myfile){     //printing result to terminal and writing to the file

    max_score=0;
    int lenA = A.length();
    int lenB = B.length();
    //double matrix[lenB+1][lenA+1];
    double** matrix = new double*[lenB+1];              //allocating memory
 
    for (int i = 0; i < lenB+1; i++) {                 //allocating memory
        matrix[i] = new double[lenA+1];
    }

    for(int j=0;j<=lenA;j++){                   //making first row all 0
        matrix[0][j]=0;
    }

    vector<int> i_index;
    vector<int> j_index;
    for(int i=0;i<=lenB;i++){                   //making first colmun all 0
        matrix[i][0]=0;
    }
    //for(int i=0; i<=lenB;i++){
    //    for(int j=0;j<=lenA;j++){
    //        cout<<matrix[i][j]<<" ";
    //    }
    //    cout<<endl;
    //}

    double findmax[4];                          //findmax stores 4 values and selects max as score for cell
    for(int i=1; i<=lenB;i++){                  //calculating scores for each cell
        for(int j=1;j<=lenA;j++){
            int operation;                      //operation stores the value of match or mismatch
            if(A[j-1]==B[i-1]){
                operation=MATCH;
                //cout<<"equal"<<endl;
                //cout<<j<<i
            }else{
                operation=MISMATCH;
            }
            findmax[0] = matrix[i-1][j-1]+operation;        //if matches add match number to S i-1 j-1 else add mismatch
            findmax[1] = matrix[i][j-1]+GAP;                //adding gap to cell just at left
            findmax[2] = matrix[i-1][j]+GAP;                //adding gap to cell just upper cell 
            findmax[3] = 0;                                 //0
            int max=0;
            for(int k=0;k<4;k++){                           //finding max
                if(max<findmax[k]){
                    max=findmax[k];
                }
            }
            //cout<<max<<endl;
            matrix[i][j]=max;                               //assigning to the cell
            if(max>max_score){                              //if max is greater than old max(max_score) means max_score is not maximum score, so empty index vectors and update max_score
                i_index.clear();                            //it stores i index of max_score
                j_index.clear();                            //it stores j index of max_score
                i_index.push_back(i);                       //add new i value after deleting old ones
                j_index.push_back(j);                       //add new j value after deleting old ones
                max_score=max;                              //update max_score
            }else if(max==max_score){                       //if it is existed already, just add new ones to vectors
                i_index.push_back(i);
                j_index.push_back(j);
            }


        }
    }
    set<string> ans;                                    //storing answer
    for(long unsigned int i=0;i<i_index.size();i++){
        string s = "";                                 // at first string is "", after travceback it will filled but it will be reverse, so I will reverse using reverse func
        int my_i=i_index[i],my_j = j_index[i];
        while(matrix[my_i][my_j]!=0){
            s = s+A[my_j-1];
            //cout<<"my_j "<<my_j<<endl;
            my_i--;
            my_j--;
        }
        reverse(s.begin(), s.end());                    //reversing string
        ans.insert(s);                                  //adding to answer set, it is set because it stores in alphabetical order
    }

    if (myfile.is_open())
    {
    }else {
        cout << "Unable to open file";
    }
    auto endl_it = ans.end();                       //printing results and writing into file
    endl_it--;
    cout<<A<<" - "<<B<<endl;
    myfile<<A<<" - "<<B<<"\n";
    cout<<"Score: "<<max_score<<" Sequence(s):";
    myfile<<"Score: "<<max_score<<" Sequence(s):";
    for(auto it = ans.begin();it!=ans.end();it++){
        if(max_score!=0){
            cout<<" \""<<*it<<"\"";
            myfile<<" \""<<*it<<"\"";               //printing results and writing into file
        }
    }
    myfile<<"\n";                                   //printing results and writing into file
    cout<<endl;

    for (int i = 0; i < lenB+1; i++) {              //deallocating memory
        delete [] matrix[i];
    }
    delete [] matrix;


}



int main(int argc, char**argv){
    string fname;
    //cin>>fname;             //filename as input
    fname = argv[1];
    //file.open(fname);       //open file
    ifstream file(fname);
    if(!file){              //if not exist give error
        cerr<<"File not found"<<endl;
        exit(1);
    }
    MATCH = stoi(argv[3]);          //assing values
    MISMATCH = stoi(argv[4]);       //assing values
    GAP = stoi(argv[5]);            //assing values
    set<string> words;
    string line;
    while(file){
        getline(file, line, '\n');  //read all words into set, it stores in alphabetical order
        words.insert(line);
    }
    string A;
    string B;
    string outfile_name = argv[2];
    ofstream myfile (outfile_name);
    auto end_it = --words.end();
    for(auto it = words.begin();it!=end_it;it++){       //for each word combination find answer
        auto sec = it;
        sec++;
        for(auto itr = sec;itr!=words.end();itr++){
            
            my_func(*it, *itr, myfile);
            
        }
    }
    myfile.close();                 //closing output file
    file.close();                   //closing input file
    return 0;
}