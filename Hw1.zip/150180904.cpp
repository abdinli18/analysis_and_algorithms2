/* @Author
Student Name: Elvin Abdinli
Student ID: 150180904*/

//for compile and run
///////////////////////////
//g++ -std=c++11 150180904.cpp -o 150180904
//./150180904 DFS TWO TWO FOUR
//./150180904 BFS TWO TWO FOUR
///////////////////////////

#include <iostream>
#include<bits/stdc++.h>
#include <map>
#include <vector>

using namespace std;






class Node{                       //node containing map instead of matrix and vector storing childs
public:
    map<char,int> matrix;
    vector<Node*> child;
    Node(){};
    ~Node(){};
};



class my_queue{                   //queue used in bfs as stl queue is not allowed
public:
  Node* my_node;
  my_queue* next;
  my_queue(){
    next=NULL;
  }
  ~my_queue(){};
};







class Tree{                     //tree
public:    
    Node* root;               //root
    Tree(){
        root=NULL;
        max_len_string=0;
        num_of_visited_nodes=0;
        max_kept_in_memo=0;
    }
    ~Tree(){};
    void start_Tree(string, string, string);      //function and variables used
    void construct_Tree(Node&);
    void delete_tree(Node&);
    void find_dfs(Node&);
    void find_bfs(my_queue&);
    string a;
    string b;
    string c;
    int len_a;
    int len_b;
    int len_c;
    int max_len_string;
    my_queue* head_queue;
    int num_of_visited_nodes;
    int max_kept_in_memo;
    my_queue* end_of_queue;
    Node* dfs_sol;
    Node* bfs_sol;
    vector<char> letters;
    vector<char> char_not_zero;
    bool dfs_find = false;
    bool bfs_find = false;
};


void Tree::delete_tree(Node& node){             //delete the tree at the end
    for(int i=0;i<node.child.size();i++){
        delete_tree(*node.child[i]);
    }
    //if(&node!=NULL){
      delete &node;
    //}
}


/*void Tree::find_bfs(my_queue& queue_node){
    //if(!bfs_find){
    //cout<<"bfs control"<<endl;
    Node* newnode = queue_node.my_node;
    int int_a = len_a-1;
    int int_b = len_b-1;
    int int_c = len_c-1;
    int carry = 0;
    int first_int=0;
    int second_int=0;
    int sum_int=0;
    bool is_prb = false;
    for(int m=1;m<=max_len_string;m++){
        if(newnode->matrix[a[int_a]]!=-1 && newnode->matrix[b[int_b]]!=-1 && newnode->matrix[c[int_c]]!=-1){
            if(int_a>=0){
                first_int = newnode->matrix[a[int_a]];
            }else{
                first_int=0;
            }
            if(int_b>=0){
                second_int = newnode->matrix[b[int_b]];
            }else{
                second_int=0;
            }
            if(int_c>=0){
                sum_int  = newnode->matrix[c[int_c]];
            }else{
                sum_int=0;
            }
            if(carry+first_int + second_int!=sum_int+10*((first_int + second_int+carry)/10)){
                //if(!dfs_find){
                  //dfs_sol=&newnode;
                  //dfs_find=true;
                  //break;
                //}
                is_prb=true;
                break;
            }else{
                int_a--;
                int_b--;
                int_c--;
                carry = (first_int+second_int+carry)/10;
            }
        }else{
          is_prb=true;
        }
        if(is_prb){
          break;
        }
      }
    if(!is_prb){
      if(!bfs_find){
        bfs_sol=newnode;
        bfs_find=true;
      }
    }
  //}*/
  //cout<<"loopa"<<endl;
  /*if(!bfs_find){
    cout<<"ici"<<endl;
    my_queue* queue_element = new my_queue;
    queue_element->my_node = &newnode;
    cout<<"bes bura"<<endl;
    if(head_queue!=NULL){
      my_queue* traverse = head_queue;
      while(traverse->next!=NULL){
        traverse=traverse->next;
      }
      traverse->next = queue_element;
      queue_element->next=NULL;
    }else{
      cerr<<"error ihtimal"<<endl;
      head_queue = queue_element;
      queue_element->next=NULL;
    }
    cout<<"heeey"<<endl;
    for(int k=0;k<newnode.child.size();k++){
      find_bfs(*newnode.child[k]);
    }  

  }*/
  ////////////////////////////////
  /*if(!bfs_find){
    //my_queue* que = new my_queue;
    my_queue* traverse = &queue_node;
    while(traverse->next!=NULL){
      traverse=traverse->next;
    }
    for(int k=0;k<queue_node.my_node->child.size();k++){
      my_queue* que = new my_queue;
      traverse->next = que;
      que->my_node = queue_node.my_node->child[k];
      traverse=traverse->next;
    }
    my_queue* tail = head_queue;
    head_queue = head_queue->next;
    delete tail;
    find_bfs(*head_queue);
  }
}*/



void Tree::find_bfs(my_queue& queue_node){            //finding solution using bfs
    max_kept_in_memo=1;
    end_of_queue = head_queue;
    int num_in_memo=1;
    while(!bfs_find){
      num_of_visited_nodes++;
      Node* newnode = head_queue->my_node;
      int int_a = len_a-1;
      int int_b = len_b-1;
      int int_c = len_c-1;
      int carry = 0;
      int first_int=0;
      int second_int=0;
      int sum_int=0;
      bool is_prb = false;
      for(int m=1;m<=max_len_string;m++){//checking whether it is solution or not
          if(newnode->matrix[a[int_a]]!=-1 && newnode->matrix[b[int_b]]!=-1 && newnode->matrix[c[int_c]]!=-1){
              if(int_a>=0){
                  first_int = newnode->matrix[a[int_a]];
              }else{
                  first_int=0;
              }
              if(int_b>=0){
                  second_int = newnode->matrix[b[int_b]];
              }else{
                  second_int=0;
              }
              if(int_c>=0){
                  sum_int  = newnode->matrix[c[int_c]];
              }else{
                  sum_int=0;
              }
              if(carry+first_int + second_int!=sum_int+10*((first_int + second_int+carry)/10)){
                  is_prb=true;
                  break;
              }else{
                  int_a--;
                  int_b--;
                  int_c--;
                  carry = (first_int+second_int+carry)/10;
              }
          }else{
            is_prb=true;
          }
          if(is_prb){
            break;
          }
        }

      if(!is_prb){
        if(!bfs_find){
          bfs_sol=newnode;//is it is solution stop
          bfs_find=true;
        }
      }
    if(!bfs_find){                        //if not solution continue to search
      my_queue* traverse = end_of_queue;
      while(traverse->next!=NULL){
        traverse=traverse->next;
      }
      for(int k=0;k<head_queue->my_node->child.size();k++){
        my_queue* que = new my_queue;
        traverse->next = que;
        que->my_node = head_queue->my_node->child[k];
        traverse=traverse->next;
        num_in_memo++;
      }
      if(num_in_memo>max_kept_in_memo){
        max_kept_in_memo=num_in_memo;
      }
      end_of_queue = traverse;
      my_queue* tail = head_queue;
      head_queue = head_queue->next;
      delete tail;
      num_in_memo--;

    }
  }
}



int inc=0;

void Tree::find_dfs(Node& newnode){             //searching the solution using dfs
    inc++;
    num_of_visited_nodes++;
    if(!dfs_find){
      for(int i=0;i<newnode.child.size();i++){
          find_dfs(*newnode.child[i]);
      }
    }
    //num_of_visited_nodes++;
    if(max_kept_in_memo<inc){
      max_kept_in_memo=inc;
    }
    int int_a = len_a-1;
    int int_b = len_b-1;
    int int_c = len_c-1;
    int carry = 0;
    int first_int=0;
    int second_int=0;
    int sum_int=0;
    bool is_prb = false;
    for(int m=1;m<=max_len_string;m++){         //checking whether it is the solution or not
        if(newnode.matrix[a[int_a]]!=-1 && newnode.matrix[b[int_b]]!=-1 && newnode.matrix[c[int_c]]!=-1){
            if(int_a>=0){
                first_int = newnode.matrix[a[int_a]];
            }else{
                first_int=0;
            }
            if(int_b>=0){
                second_int = newnode.matrix[b[int_b]];
            }else{
                second_int=0;
            }
            if(int_c>=0){
                sum_int  = newnode.matrix[c[int_c]];
            }else{
                sum_int=0;
            }
            if(carry+first_int + second_int!=sum_int+10*((first_int + second_int+carry)/10)){
                is_prb=true;
                break;
            }else{
                int_a--;
                int_b--;
                int_c--;
                carry = (first_int+second_int+carry)/10;
            }
        }else{
          is_prb=true;
        }
        if(is_prb){
          break;
        }
      }
    if(!is_prb){
      if(!dfs_find){
        dfs_sol=&newnode;   //if solution stop
        dfs_find=true;
      }
    }
    inc--;
}


void Tree::construct_Tree(Node& newnode){
    if(root==NULL){                         //if root is null make newnode root
        root = &newnode;
    }
    int len=0;
    vector<char> not_added_yet_letter;        // store the letters that are not assigned to number
    vector<int> added_int;                    // assigned integers
    for(int j=0; j<newnode.matrix.size();j++){
        if(newnode.matrix[letters[j]]==-1){
            not_added_yet_letter.push_back(letters[j]);
        }else{
            len++;
            added_int.push_back(newnode.matrix[letters[j]]);
        }
    }

    if(not_added_yet_letter.size()==0){           // means it is the last leaf
        return;
    }
        for(int j=0;j<10;j++){
            bool not_used_int=true;
            for(int t=0;t<added_int.size();t++){
                if(j==added_int[t]){
                    not_used_int=false;
                    break;
                }
            }
            if(not_used_int==true){
                if(newnode.matrix[a[0]]==0 || newnode.matrix[b[0]]==0 || newnode.matrix[c[0]]==0){
                    continue;
                }else{
                    bool okay_for_add=true;
                    int int_a = len_a-1;            //checking appropriate node or not
                    int int_b = len_b-1;
                    int int_c = len_c-1;
                    int carry = 0;
                    int first_int=0;
                    int second_int=0;
                    int sum_int=0;
                    for(int m=1;m<=max_len_string;m++){

                        if(newnode.matrix[a[int_a]]!=-1 && newnode.matrix[b[int_b]]!=-1 && newnode.matrix[c[int_c]]!=-1){
                            if(int_a>=0){
                                first_int = newnode.matrix[a[int_a]];
                            }else{
                                first_int=0;
                            }
                            if(int_b>=0){
                                second_int = newnode.matrix[b[int_b]];
                            }else{
                                second_int=0;
                            }
                            if(int_c>=0){
                                sum_int  = newnode.matrix[c[int_c]];
                            }else{
                                sum_int=0;
                            }
                            if(carry+first_int + second_int!=sum_int+10*((first_int + second_int+carry)/10)){
                                okay_for_add=false;
                                break;
                            }else{
                                int_a--;
                                int_b--;
                                int_c--;
                                carry = (first_int+second_int+carry)/10;
                            }
                        }
                        if(okay_for_add==false){
                            break;
                        }
                    }
                    if(okay_for_add){         //if it is okay to add
                        Node* newchild = new Node;
                        newchild->matrix = newnode.matrix;
                        newchild->matrix[not_added_yet_letter[0]] = j;
                        newnode.child.push_back(newchild);
                        construct_Tree(*newchild);//continue adding
                    }
                }
            }
        }
}

void Tree::start_Tree(string a, string b, string c){
    char_not_zero.push_back(a[0]);//first letters can not be zero
    char_not_zero.push_back(b[0]);
    char_not_zero.push_back(c[0]);
    string all_letters = a+b+c;
    sort(all_letters.begin(), all_letters.end());//sorting them
    Node* newnode = new Node;
    for(int i=0;i<all_letters.size();i++){
        if(newnode->matrix[all_letters[i]]!=-1){
            letters.push_back(all_letters[i]);
            newnode->matrix[all_letters[i]] = -1;
        }
    }
    construct_Tree(*newnode);//adding to tree
}

int main(int argc, char**argv){
    //-fsanitize=leak;
    string operation = argv[1];
    string first = argv[2];
    string second = argv[3];
    string sum = argv[4];
    //string operation="DFS";
    //string first = "TWO";
    //string second = "TWO";
    //string sum = "FOUR";    
    Tree T;
    T.a = first;
    T.b = second;
    T.c = sum;
    T.len_a = T.a.size();
    T.len_b = T.b.size();
    T.len_c = T.c.size();
    T.max_len_string = T.len_c;
    auto start = chrono::high_resolution_clock::now();
    T.start_Tree(first, second, sum);
    if(operation=="DFS"){
        
         
        T.find_dfs(*T.root);
	      auto end = chrono::high_resolution_clock::now();
	      chrono::duration<double> diff = end - start;
        //cout << setw(9) << diff.count() << " s\n";
        cout<<"Algorithm: "<<operation<<endl;
        cout<<"Number of visited nodes: "<<T.num_of_visited_nodes<<endl;
        cout<<"Maximum number of nodes kept in the memory: "<< T.max_kept_in_memo<<endl;
        cout<<"Running time: "<< setw(9) << diff.count() << " s\n";
        cout<<"Solution: "; 
        for(int i=0;i<T.letters.size();i++){
          cout<<T.letters[i]<<": "<<T.dfs_sol->matrix[T.letters[i]];
          if(i!=(T.letters.size()-1)){
            cout<<", ";
          }
        }
        cout<<endl;
        T.delete_tree(*T.root);
        //cout<<"deneme";
    }else if(operation=="BFS"){
        my_queue* queue_node = new my_queue;
        queue_node->my_node = T.root;
        T.head_queue = queue_node;
        //cout<<"dondum"<<endl;
        //auto start = chrono::high_resolution_clock::now();
        T.find_bfs(*T.head_queue);
	      auto end = chrono::high_resolution_clock::now();
	      chrono::duration<double> diff = end - start;
        //cout << setw(9) << diff.count() << " s\n";
        //cout<<"don"<<endl;
        cout<<"Algorithm: "<<operation<<endl;
        cout<<"Number of visited nodes: "<<T.num_of_visited_nodes<<endl;
        cout<<"Maximum number of nodes kept in the memory: "<< T.max_kept_in_memo<<endl;
        cout<<"Running time: "<< setw(9) << diff.count() << " s\n";
        cout<<"Solution: "; 
        for(int i=0;i<T.letters.size();i++){
          cout<<T.letters[i]<<": "<<T.bfs_sol->matrix[T.letters[i]];
          if(i!=T.letters.size()-1){
            cout<<", ";
          }
        }
        cout<<endl;
        while(T.head_queue!=NULL){
          my_queue* tail = T.head_queue;
          T.head_queue = T.head_queue->next;
          delete tail;
        }
        T.delete_tree(*T.root);
    }
    
    return 0;
}