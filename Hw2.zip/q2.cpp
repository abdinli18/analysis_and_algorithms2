/* @Author
Student Name: Elvin Abdinli
Student ID: 150180904*/

//for compile and run
///////////////////////////
//./q2
///////////////////////////




#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <vector>
#include <algorithm>
#include <set>

# define INF 0x3f3f3f3f

using namespace std;


class my_node{
public:
    string prev; //stores previous vertex
    string cur;//current vertex
    int edge_weight;//stores weight of edge
    int total_weight;//
    string command;//
    int enemy_dist; 
    bool operator<(const my_node& node) const{
        return this->edge_weight < node.edge_weight;
    }
};


class List{
public:
    void dijkstra_algo(multiset<my_node>& order,map<string,vector<my_node>>&m);
};

map<string, bool> inMST;//stores node is in mst or not
map<string, int> weightnode;//stores weight
multiset<my_node> answer;//stores final mst nodes
string first_church;//stores name of first church
vector<my_node*> delete_vec;//stores nodes to be deleted
map<string, int> error;

void List::dijkstra_algo(multiset<my_node>& order,map<string,vector<my_node>>&m){
    map<string, string> res;        //this map stores the final result or answer for thi question. it stores the parent of each node and it helps to return the path from Mo to Ma
    res["Ma"] = "Ma";
    string vertex="Ma";
    for(long unsigned int j=0;j<m["Ma"].size();j++){        //add neigjbors to order set and update the weights
        if(inMST[m["Ma"][j].cur]==false && weightnode[m["Ma"][j].cur]>m["Ma"][j].edge_weight && m["Ma"][j].cur[0]!='E'){
            if(error.find(m["Ma"][j].cur) != error.end()){
                if(error[m["Ma"][j].cur]>4){
                    order.insert(m["Ma"][j]);
                    weightnode[m["Ma"][j].cur]=m["Ma"][j].edge_weight;
                    res[m["Ma"][j].cur] = m["Ma"][j].prev;                    
                }
            }else{
                order.insert(m["Ma"][j]);
                weightnode[m["Ma"][j].cur]=m["Ma"][j].edge_weight;
                res[m["Ma"][j].cur] = m["Ma"][j].prev;
            }

        }
    }
    //cerr<<"geldim"<<endl;
    while(!order.empty()){          //then while order is not empty search nodes which is in located in order set
        auto it = order.begin();
        string a=it->cur;
        string b=it->prev;
        string u = it->cur;
        my_node ma = *it;
        order.erase(it);
        
        for(long unsigned int t=0;t<m[u].size(); t++){
            string v = m[u][t].cur;
            
            int weight = m[u][t].edge_weight + weightnode[a];
            //cout<<weight<<endl;
            if(weightnode[v] > weight){          //if it not added and has weight less than before add to order
            //cerr<<"gel"<<endl;
                //cout<<v<<"vyi print"<<endl;
                if(v[0]!='E'){
                    //if(v[0]=='S' || v[0]=='R' || v=="Mo"){
                        if(error.find(v) != error.end()){
                            if(error[v]>4){
                                //cerr<<v<<" "<<error[v]<<endl;
                                //cout<<"aaaa"<<endl;
                                order.insert(m[u][t]);                             // and update the weight
                                weightnode[v] = weight;
                                res[v]=u;
                            }//else{
                        }else{
                            order.insert(m[u][t]);                             // and update the weight
                            weightnode[v] = weight;
                            res[v]=u;
                            //cout<<"bbbbb"<<endl;                            
                        }
                        //}
                    //}
                }

            }
            if(!(inMST[a]&& inMST[b]) ){
                // Updating key of v
                //hey.push_back(*it);
                //cout<<ma.cur<<endl;
                //answer.insert(ma);                 //add to final nodes of mst
                //res[v]=u;
                inMST[u]=true;
                inMST[b]=true;
            } 
        }
                        //erase after operation
    }
    string des="Mo";                //starting from Mo till Ma add all nodes of shortest path to vector
    vector<string> resvec;
    while(des!=res[des]){
        resvec.push_back(des);
        des = res[des];
    }
    resvec.push_back("Ma");         // add Ma at the end as it is first node.
    //int total = 0;

    for(int i=resvec.size()-1;i>=0;i--){    // then print the shortest path in reverse order so that it is same as correct asnwer format
        cout<<resvec[i]<<" ";
    }
    cout<<weightnode["Mo"]<<endl;           // last node is Mo
    for(int h=0;h<(int)delete_vec.size();h++){//deleting nodes
        delete delete_vec[h];
    }
}


int main(){
    List l;
    map<string, vector<my_node>> m;//

    multiset<my_node> order;//storing operatins in order set
    string fname;
    cin>>fname;
    ifstream file(fname); //opening file
    if(!file){
        cerr<<"File not found"<<endl;
        exit(1);
    }

    string s, d;
    int w;
    string line;
    inMST["GP"]=false;
    while(file){//while there somethink to add to graph 
        getline(file, line, ',');
        s=line;
        getline(file, line, ',');
        d=line;
        getline(file, line, '\n');
        w=stoi(line);
        if(true){
            my_node* node = new my_node;
            node->prev=s;
            node->cur=d;
            node->edge_weight=w;
            node->total_weight=INF;
            node->command = s+","+d+",";
            inMST[d]=false;
            inMST[s]=false;
            if(s[0]=='E'&& (d[0]=='S'||d[0]=='R')){
                if(error.find(d) != error.end()){
                    if(error[d]>w){
                        error[d]=w;
                        //cout<<"hey"<<endl;
                    }
                }else{
                    //cout<<"tapmadi"<<endl;
                    error[d]=w;
                }
              
            }
            if(d[0]=='E'&& (s[0]=='S'||s[0]=='R')){
                if(error.find(s) != error.end()){
                    if(error[s]>w){
                        error[s]=w;
                        //cout<<"heyo"<<endl;
                    }
                }else{
                  //cout<<"tapmadi"<<endl;
                    error[s]=w;
                }
              
            }
            m[s].push_back(*node);
            delete_vec.push_back(node);
            weightnode[s]=INF;
            node->cur=s;
            node->prev=d;

            m[d].push_back(*node);
            weightnode[d]=INF;
        }           
    }
    file.close();//close file
    weightnode["Ma"]=0;// Ma is first node so its weight is 0
    //map<string, multiset<my_node>>::iterator it;
    //for(it=m.begin();it!=m.end();it++){

    //}
    l.dijkstra_algo(order, m);//call dijkstra 
    return 0;
}