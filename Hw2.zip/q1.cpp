/* @Author
Student Name: Elvin Abdinli
Student ID: 150180904*/

//for compile and run
///////////////////////////
/*g++ -std=c++11 -Wall -Werror q1.cpp -o q1;*/
//./q1
///////////////////////////



#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <vector>
#include <algorithm>
#include <set>

# define INF 0x3f3f3f3f

using namespace std;



class my_node{              //my node class
public:
    string source;          //stores previous node it is connected in mst
    string dest;            //it is actually name of node
    int edge_weight;        //stores edge weight
    int total_weight;       //
    string command;         // it stores the original command as I add for example GP Ch1 both for GP and Ch1 in graph to store original version whether it is GP Ch1 or Ch1 GP, I used this string 
    bool operator<(const my_node& node) const{      //overloading due to set
        return this->edge_weight < node.edge_weight;
    }
    my_node(){};            //constructor
    ~my_node(){};           //destructor
};

class List{
public:
    List(){};               //constructor
    ~List(){};              //destructor
    void primMST(multiset<my_node>& order,map<string,vector<my_node>>&m,  int added);
};

map<string, bool> inMST;            //stores whether node is in mst or not
map<string, int> weightnode;        //stores total weight of each node
multiset<my_node> answer;                // set stores final nodes in set
string first_church;                //name of first church
vector<my_node*> delete_vec;        // vector storing which nodes to delete at the end

struct my_sort
{
    inline bool operator() (const my_node& struct1, const my_node& struct2)
    {
        return (struct1.edge_weight < struct2.edge_weight);
    }
};

void List::primMST(multiset<my_node>& order,map<string, vector<my_node>>& m, int added){

    set<my_node> :: iterator it;
    it = order.begin();             // firtsly there is first church in order set, so it is added to inMST
    string u = it->dest;
    string s = it->source;
    answer.insert(*it);             //answer set is containong final mst tree nodes
    inMST[u]=true;
    inMST["Hipp"]=true;             // As Hipp should be directly connected to GP, to avoid potential cycles, I add Hipp immediately after church to Mst
    for(int z=0;z<(int)m["GP"].size();z++){     
        if(m["GP"][z].dest=="Hipp"){
            weightnode["Hipp"] = m["GP"][z].edge_weight;
            answer.insert(m["GP"][z]);                      //this part adds Hipp to mst
            break;
        }
    }
    order.erase(it);
    for(int t=0;t<(int)m[u].size(); t++){       // at this part I add the neighbors of church to order
        string v = m[u][t].dest;
        string ss  = m[u][t].source;
        int weight = m[u][t].edge_weight+ weightnode[it->dest]; 
		if (inMST[v] == false && weightnode[v] > weight){
            inMST[u]=true;
            inMST[s]=true;
		    weightnode[v] = weight;
            order.insert(m[u][t]);
	    }
    }
                                //finally erase church from order, because its neighbors are added to order and it added to final mst nodes set 
    for(int j=0;j<(int)m["GP"].size();j++){                                                         // all neighbors of GP added to order set
        if(j!=added){
            if(inMST[m["GP"][j].dest]==false && weightnode[m["GP"][j].dest]>m["GP"][j].edge_weight){
                weightnode[m["GP"][j].dest]=m["GP"][j].edge_weight;
                if(m["GP"][j].dest!="Hipp"){                                                        //except Hipp as it is already added
                    order.insert(m["GP"][j]);
                }else{
                    answer.insert(m["GP"][j]);
                    inMST[m["GP"][j].dest]=true;
                    weightnode["Hipp"]=m["GP"][j].edge_weight;
                }
            }
        }
    }

    for(int b=0;b<(int)m["Hipp"].size();b++){                       //all neighbors of Hipp except Bas are added to order.
        int weight = weightnode["Hipp"]+ m["Hipp"][b].edge_weight;
        if(m["Hipp"][b].dest=="Ch1"){

        }
        if(inMST[m["Hipp"][b].dest]==false && weightnode[m["Hipp"][b].dest]>weight){
            if(m["Hipp"][b].dest[0]!='B'){                          //we check if it is Bas or not
                weightnode[m["Hipp"][b].dest]=weight;
                order.insert(m["Hipp"][b]);
            }
        }
    }

    while(!order.empty()){                                          //while order is not empty I choose, node with lowest egde weight
        auto it = order.begin();                                    //because order is set type, first element already has lowest edge weight
        string u = it->dest;                                        // I overload operator< for this
        string s= it->source;

        for(int t=0;t<(int)m[u].size(); t++){                       //add all neighbors
            string v = m[u][t].dest;
            int weight = m[u][t].edge_weight + weightnode[it->dest];
            
		        if (inMST[v] == false){

                    if(u[0]=='H' && v[0]=='H' && u[1]=='p' && v[1]=='p'){
                        continue;
                    }else if((u=="Hipp" && v[0]=='B') || (v=="Hipp" && u[0]=='B')){
                        continue;
                    }else{
                        order.insert(m[u][t]);
                        weightnode[v] = weight;
                    }

		        }
            if(!(inMST[it->dest]&& inMST[it->source]) ){            // it avoids cycle
                answer.insert(*it);
                inMST[u]=true;
                inMST[s]=true;
            }        
                    
        }
    
        order.erase(it);                    //erase from erder after adding to answer set
    }



    int counter=0;                          //counter to count final weight
    set<my_node> :: iterator itr;
    for(itr=answer.begin(); itr!=answer.end();itr++){       //printing edges used
        cout<<itr->command<<itr->edge_weight<<endl;
        counter+=itr->edge_weight;
    }
    cout<<counter<<endl;                                    //printing weight 

    for(int h=0;h<(int)delete_vec.size();h++){              //deleting nodes which allocate memory by using new
        delete delete_vec[h];
    }

    return;             //return
}



int main(){
    List l;
    map<string, vector<my_node>> m;
    multiset<my_node> order;
    //ifstream file;
    string fname;
    cin>>fname;             //filename as input
    //file.open(fname);       //open file
    ifstream file(fname);
    if(!file){              //if not exist give error
        cerr<<"File not found"<<endl;
        exit(1);
    }

    string s, d;
    int w;
    string line;
    inMST["GP"]=false;
    while(file){                         //reading file
        getline(file, line, ',');               //
        s=line;                                 //
        getline(file, line, ',');               //
        d=line;                                 //
        getline(file, line, '\n');              //
        w=stoi(line);                           //
        my_node* node = new my_node;            //creating node to add graph
        node->source=s;
        node->dest=d;
        node->edge_weight=w;
        node->total_weight=INF;
        node->command = s+" "+d+" ";
        inMST[d]=false;
        inMST[s]=false;
        m[s].push_back(*node);                   //adding to graph
        delete_vec.push_back(node);              //this vector stores the initially created nodes using new in order to delete them at the end;
        weightnode[s]=INF;                      //initially set to infinity
        node->dest=s;
        node->source=d;
        m[d].push_back(*node);
        weightnode[d]=INF;
        
    }
    file.close();                               //closing file
    string c="Ch";

    sort(m["GP"].begin(), m["GP"].end(), my_sort());        //sorting the neighbors of GP by edge weight in order to connect church with lowest edge first
    int i=0;
    while(1){
        if(m["GP"][i].dest[0]==c[0] && m["GP"][i].dest[1]==c[1]){
            order.insert(m["GP"][i]);                               //find the index of church and add it to set<my_node> order. It stores the nodes to be checked
            first_church = m["GP"][i].dest;                         // after checking the node I erase it from set order
            break;
        }
        i++;
    }

    inMST["GP"]=true;                                               //GP added to mst so inmst["GP"] is true now. inMst[] is map and stores whether node is already added to tree or not.
    weightnode["GP"]=0;                                             //it helps to avoid cycles
    weightnode[m["GP"][i].dest]=m["GP"][i].edge_weight;             //as GP has weight 0, church connected to GP will have its edge weight as its total weight
    l.primMST(order, m,i);                                          //start prim
   
}